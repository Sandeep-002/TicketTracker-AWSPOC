import json
import urllib.parse
import boto3

s3 = boto3.client('s3')

def lambda_handler(event, context):
    for record in event.get('Records', []):
        bucket = record['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(record['s3']['object']['key'], encoding='utf-8')
        
        # Skip if already a thumbnail
        if key.startswith('thumbnails/'):
            continue
            
        print(f"File uploaded to {bucket}: {key}")
        thumbnail_key = f"thumbnails/thumb_{key.split('/')[-1]}"
        
        # Write thumbnail marker file back to S3
        s3.put_object(
            Bucket=bucket,
            Key=thumbnail_key,
            Body=f"Thumbnail marker generated for {key}".encode('utf-8'),
            ContentType='text/plain'
        )
        print(f"Generated thumbnail: {thumbnail_key}")
        
    return {
        'statusCode': 200,
        'body': json.dumps('Thumbnail generated successfully!')
    }
